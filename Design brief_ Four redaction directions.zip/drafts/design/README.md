# Design drafts

UI mockups for the buyer-side screens. Static HTML, no build step — open any file in a browser.

## Ready to open

| File | What it is |
|---|---|
| `problem-page.html` | The problem page: heading, tags, list of companies ready to solve it. Current direction. |
| `all-directions.html` | Everything explored so far, newest at the top: 5a collapsed list, 4a list with an open row, 3a ticket with the agent rail, 2a/2b product UI, 1a–1d studies of how withholding is rendered. |

Both are self-contained (fonts and icons inlined) and work offline.

## Sources

`src/` holds the editable originals.

- `Problem page.dc.html` — the standalone problem page
- `Two-sided view.dc.html` — all directions on one canvas
- `support.js` — runtime both files load; keep it next to them

Open `src/Problem page.dc.html` directly in a browser to edit and reload. Rebuild the
self-contained copies only if you need a single file to send around.

## Decisions baked into these screens

- The buyer sees the vendor's name and website only after both sides accept
  (`AnonymousMatchView`, PLAN.md §3.5). Before that: industry, size, summary, score.
- No figure from the other side is ever displayed. Compatibility is stated, amounts are not
  (docs/DESIGN_BRIEF.md §6).
- The eliminated candidate is shown with its reason, per PLAN.md §8.3.
- The word for what the seller cannot see is "withheld".

## Stack notes

Type: Instrument Sans, with Spectral for the buyer's own words in the earlier directions.
Icons: Lucide. Palette: ground `#F4F6F8`, ink `#16323A`, signal `#2F6D52`, withheld `#8E9897`.
Compatible and unresolved states differ by shape as well as colour.
